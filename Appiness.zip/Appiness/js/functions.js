$(document).ready(function() {
    var url = window.location.href;
    var urlId = url.split('#').pop();
    $('.accordion_title').click(function() {
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
            $(this).next().removeClass('show').slideUp('slow');
        } else {
            $('.accordion_title').removeClass('active');
            $('.accordion_content').removeClass('show').slideUp('slow');
            $(this).addClass('active');
            $(this).next().addClass('show').slideDown('slow');
        }
    });
    if (urlId != '') {
        if (urlId != url && $('#' + urlId).length >= 1) {
            $('#' + urlId).addClass("active");
            $('#' + urlId).next('.accordion_content').addClass('show').slideDown('slow');
        }
    }
    $('[data-icon]').each(function() {
        $(this).addClass('font-icon');
    });
    $("#Testimonials_Scroll").flexisel({
        visibleItems: 2,
        itemsToScroll: 1,
        animationSpeed: 1500,
        infinite: true,
        navigationTargetSelector: null,
        autoPlay: {
            enable: true,
            interval: 5000,
            pauseOnHover: true
        },
        responsiveBreakpoints: {
            portrait: {
                changePoint: 480,
                visibleItems: 1,
                itemsToScroll: 1
            },
            landscape: {
                changePoint: 640,
                visibleItems: 1,
                itemsToScroll: 1
            },
            phablet: {
                changePoint: 780,
                visibleItems: 2,
                itemsToScroll: 1
            },
            tablet: {
                changePoint: 840,
                visibleItems: 2,
                itemsToScroll: 1
            }
        }
    });
    const call_animation = (entries, observer) => {
        entries.forEach(entry => {
            entry.target.classList.toggle("animation_class", entry.isIntersecting);
        });
    };
    const Obs = new IntersectionObserver(call_animation);
    const obsOptions = {};
    const ELs_call_animation = document.querySelectorAll('[data_call_animation]');
    ELs_call_animation.forEach(EL => {
        Obs.observe(EL, obsOptions);
    });
    var delay_time = 0;
    $(".animation_delay ul li,.animation_delay_after li").each(function() {
        $(this).css("animation-duration", delay_time + "s");
        delay_time += 1;
        if (delay_time > 17) {
            delay_time = 1;
        }
    });

});